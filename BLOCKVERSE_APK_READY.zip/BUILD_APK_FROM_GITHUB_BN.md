# Blockverse APK বানানোর সহজ নিয়ম

## 1) GitHub-এ Upload
এই পুরো project folder-এর সব ফাইল GitHub repository-তে upload করো।

## 2) Actions চালু করো
GitHub repository খুলে:
- **Actions** চাপো
- **Build Debug APK** workflow বেছে নাও
- **Run workflow** চাপো
- `main` branch নির্বাচন করে আবার **Run workflow** চাপো

## 3) APK Download
Build শেষ হলে:
- ওই workflow run খুলে **Artifacts** অংশে যাও
- **app-debug-apk** চাপো
- ZIP download করো
- ZIP খুললে `app-debug.apk` পাবে

## গুরুত্বপূর্ণ
- এই APK **testing-এর জন্য**।
- Google Play Store-এর জন্য পরে **signed AAB** বানাতে হবে।
- Play Store developer account, payment ও identity verification-এর মতো account-related কাজ হলে parent/guardian-এর সাহায্য নাও।
